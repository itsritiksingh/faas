def some_func(varname)
  puts "Varname is " << varname
  return 42
end